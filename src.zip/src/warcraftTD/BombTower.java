package warcraftTD;

public class BombTower extends Tower{
	public BombTower(Position p) {
		super(p, "images/BombTower.png", 20, 60, 0.2);
	}
}
