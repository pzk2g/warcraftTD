package warcraftTD;

public class ArcherTower extends Tower {
	public ArcherTower(Position p) {
		super(p, "images/ArcherTower.png", 15, 50, 0.3);
	}
}
