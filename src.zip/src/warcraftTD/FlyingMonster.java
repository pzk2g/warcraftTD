package warcraftTD;

public class FlyingMonster extends Monster {
	public FlyingMonster(Position p) {
		super(p, "images/FlyingMonster.png", 3, 0.02, 8);
	}
}
