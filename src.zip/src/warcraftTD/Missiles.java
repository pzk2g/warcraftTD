package warcraftTD;

public abstract class Missiles {
	Position p;
	String chemin;
	Position nextP;
	
}
